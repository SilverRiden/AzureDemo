﻿using Microsoft.ML;
using Microsoft.ML.Runtime.Data;
using System;
using System.IO;
using Microsoft.ML.Core.Data;
using Microsoft.ML.Runtime.Api;
using Microsoft.ML.Transforms;
using Microsoft.ML.Transforms.Categorical;
using Microsoft.ML.Transforms.Normalizers;
using Microsoft.ML.Transforms.Text;

namespace MLNetUbike
{
    class Program
    {
        static readonly string _trainDataPath = 
            Path.Combine(Environment.CurrentDirectory, "Datas", "ubike.csv");

        static readonly string _testDataPath = 
            Path.Combine(Environment.CurrentDirectory, "Datas", "ubiketest.csv");

        static readonly string _modelPath = 
            Path.Combine(Environment.CurrentDirectory, "Datas", "Model.zip");

        static TextLoader reader;

        static void Main(string[] args)
        {
            //Create a ML.NET environment  
            var mlContext = new MLContext();

            reader = mlContext.Data.TextReader(new TextLoader.Arguments()
            {
                Separator = ",",
                HasHeader = true,
                Column = new[]
                            {
                                new TextLoader.Column("SiteCode", DataKind.Text, 0),
                                new TextLoader.Column("SiteName", DataKind.Text, 1),
                                new TextLoader.Column("Total", DataKind.R4, 2),
                                new TextLoader.Column("Sbi", DataKind.R4, 3),
                                new TextLoader.Column("Mday", DataKind.DateTime, 4),
                                new TextLoader.Column("Bemp", DataKind.R4, 5)
                            }
            });

            //Step1 : Load and transform data
            IDataView trainingDataView = reader.Read(_trainDataPath);


            //Step2 : Transform your data and add a learner
            /*
             * Transforms.CopyColumns 要預測的欄位
             * Transforms.OneHotEncodingEstimator 訓練模型的算法需要數字特徵，使用OneHotEncodingEstimator轉換
             * Transforms.Concatenate 指出特徵資料
             * Regression.Trainers.FastTree 選擇學習演算法
             */
            var pipeline = mlContext.Transforms.CopyColumns("Sbi", "Label")
            .Append(mlContext.Transforms.Categorical.OneHotEncoding("SiteCode"))
            .Append(mlContext.Transforms.Categorical.OneHotEncoding("Mday"))
            .Append(mlContext.Transforms.Categorical.OneHotEncoding("Total"))
            .Append(mlContext.Transforms.Concatenate("Features", "SiteCode", "Mday", "Total"))
            .Append(mlContext.Regression.Trainers.FastTree());


            //Step3 : Train the model
            var model = pipeline.Fit(trainingDataView);

            //Step4 : Save the model
            using (var fileStream = new FileStream(_modelPath, FileMode.Create
                , FileAccess.Write, FileShare.Write))
            {
                mlContext.Model.Save(model, fileStream);
            }

            //Step5 : Evaluate the model
            EvaluateModel(mlContext, model);

            //Step6 : Prediction
            TestPrediction(mlContext);
        }
        
        private static void EvaluateModel(MLContext mlContext, ITransformer model)
        {
            IDataView dataView = reader.Read(_testDataPath);
            var predictions = model.Transform(dataView);
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");

            Console.WriteLine();
            Console.WriteLine($"*       Model quality metrics evaluation         ");
            Console.WriteLine($"*------------------------------------------------");
            Console.WriteLine($"*       RSquared Score(0~1 愈趨近1愈好):      {metrics.RSquared:0.##}");
            Console.WriteLine($"*       RMS loss(值愈小愈好):      {metrics.Rms:#.##}");
        }

        private static void TestPrediction(MLContext mlContext)
        {
            //load the model
            ITransformer loadedModel;
            using (var stream = new FileStream(_modelPath, FileMode.Open
                , FileAccess.Read, FileShare.Read))
            {
                loadedModel = mlContext.Model.Load(stream);
            }

            //Prediction test
            //Create prediction function and make prediction.
            var predictionFunction = loadedModel.MakePredictionFunction<Ubike, UbikePrediction>(mlContext);

            //Test Sample Data
            var sampledata = new Ubike()
            {
                SiteCode = "1001",
                SiteName = "大鵬華城",
                Total = 38,
                Sbi = 0, // To predict
                Mday = DateTime.Parse("2018/11/13 23:00:00"),
                Bemp = 27 
            };
            
            var prediction = predictionFunction.Predict(sampledata);
           
            Console.WriteLine($"**********************************************************************");
            Console.WriteLine($"Predicted fare: {prediction.SbiPrediction:0.####}");
            Console.WriteLine($"**********************************************************************");
           
        }
    }
}
