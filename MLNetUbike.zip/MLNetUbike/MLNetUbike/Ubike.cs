﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Runtime.Api;

namespace MLNetUbike
{
    public class Ubike
    {
        [Column("0")]
        public string SiteCode;
        [Column("1")]
        public string SiteName;
        /// <summary>
        /// 總停車格
        /// </summary>
        [Column("2")]
        public float Total;
        /// <summary>
        /// 可借數
        /// </summary>
        [Column("3")]
        public float Sbi;
        [Column("4")]
        public DateTime Mday;
        /// <summary>
        /// 可還數
        /// </summary>
        [Column("5")]
        public float Bemp;
    }

    public class UbikePrediction
    {
        [ColumnName("Score")]
        public float SbiPrediction;
    }
}
