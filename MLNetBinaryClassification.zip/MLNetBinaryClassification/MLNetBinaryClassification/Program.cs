﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML;
using Microsoft.ML.Core.Data;
using Microsoft.ML.Runtime.Api;
using Microsoft.ML.Runtime.Data;
using Microsoft.ML.Transforms.Text;

namespace MLNetBinaryClassification
{
    class Program
    {
        static readonly string _trainDataPath = Path.Combine(Environment.CurrentDirectory, "Datas", "wikidata.tsv");
        static readonly string _testDataPath = Path.Combine(Environment.CurrentDirectory, "Datas", "wikitest.tsv");
        static readonly string _modelPath = Path.Combine(Environment.CurrentDirectory, "Datas", "Model.zip");
        static TextLoader _textLoader;

        static void Main(string[] args)
        {
            //Step 1 Create ML.NET context/local environment
            MLContext mlContext = new MLContext();

            //Step 2 Setting Data Loader
            _textLoader = mlContext.Data.TextReader(new TextLoader.Arguments()
                            {
                                Separator = "tab",
                                HasHeader = true,
                                Column = new[]
                                {
                                    new TextLoader.Column("Label", DataKind.Bool, 0),
                                    new TextLoader.Column("SentimentText", DataKind.Text, 1)
                                }
                            });

            //Step 3 Load Data
            IDataView dataView = _textLoader.Read(_trainDataPath);

            //Step 4 
            /*
             Set Feature Column : FeaturizeText("SentimentText", "Features")
             binary classification algorithms : BinaryClassification.Trainers.FastTree
             */
            var pipeline = mlContext.Transforms.Text.FeaturizeText("SentimentText", "Features")
            .Append(mlContext.BinaryClassification.Trainers.FastTree(numLeaves: 50, numTrees: 50, minDatapointsInLeafs: 20));

            //Step 5 Create and Train the Model
            var model = pipeline.Fit(dataView);

            //Step 6 Evaluate Model
            Evaluate(mlContext, model);

            //Step 7 Predict
            Predict(mlContext, model);

            //Step 8 Predict
            PredictWithModelLoadedFromFile(mlContext);
        }


        public static void Evaluate(MLContext mlContext, ITransformer model)
        {
            IDataView dataView = _textLoader.Read(_testDataPath);
            var predictions = model.Transform(dataView);
            var metrics = mlContext.BinaryClassification.Evaluate(predictions, "Label");
            Console.WriteLine();
            Console.WriteLine("Model quality metrics evaluation");
            Console.WriteLine("--------------------------------");
            Console.WriteLine($"準確率（Accuracy）(有多少比例的樣本預測正確): {metrics.Accuracy:P2}");
            Console.WriteLine($"Auc(數值愈大愈好): {metrics.Auc:P2}");
            Console.WriteLine($"F1Score(數值愈接近1愈好): {metrics.F1Score:P2}");
            Console.WriteLine("=============== End of model evaluation ===============");
            SaveModelAsFile(mlContext, model);
        }

        private static void SaveModelAsFile(MLContext mlContext, ITransformer model)
        {

            using (var fs = new FileStream(_modelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                mlContext.Model.Save(model, fs);
            }
        }

        private static void Predict(MLContext mlContext, ITransformer model)
        {
            var predictionFunction = model.MakePredictionFunction<SentimentData, SentimentPrediction>(mlContext);
           
            SentimentData sampleStatement = new SentimentData
            {
                SentimentText = "This is not the real thing"
            };
            
            var resultprediction = predictionFunction.Predict(sampleStatement);
           
            Console.WriteLine($"Sentiment: {sampleStatement.SentimentText} | Prediction: {(Convert.ToBoolean(resultprediction.Prediction) ? "正面" : "負面")} | Probability: {resultprediction.Probability} ");
        }

        public static void PredictWithModelLoadedFromFile(MLContext mlContext)
        {
           
            IEnumerable<SentimentData> sentiments = new[]
            {
                new SentimentData
                {
                    SentimentText = "Please refrain from adding nonsense to Wikipedia"
                },
                new SentimentData
                {
                    SentimentText = "He is the best, and the article should say that."
                }
            };
            
            ITransformer loadedModel;
            using (var stream = new FileStream(_modelPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                loadedModel = mlContext.Model.Load(stream);
            }
           
            var sentimentStreamingDataView = mlContext.CreateStreamingDataView(sentiments);
            var predictions = loadedModel.Transform(sentimentStreamingDataView);

            var predictedResults = predictions.AsEnumerable<SentimentPrediction>(mlContext, reuseRowObject: false);
           
            var sentimentsAndPredictions = sentiments.Zip(predictedResults, (sentiment, prediction) => (sentiment, prediction));
           
            foreach (var item in sentimentsAndPredictions)
            {
                Console.WriteLine($"Sentiment: {item.sentiment.SentimentText} | Prediction: {(Convert.ToBoolean(item.prediction.Prediction) ? "正面" : "負面")} | Probability: {item.prediction.Probability} ");
            }
        }
    }
}
